# parser.py
from ast_nodes import *
class Parser:
    def __init__(self, tokens):
        self.tokens = tokens
        self.pos = 0
    def current_token(self):
        return self.tokens[self.pos]
    def eat(self, token_type):
        token = self.current_token()
        if token[0] == token_type:
            self.pos += 1
            return token
        else:
            raise SyntaxError(f"Expected {token_type}, got {token[0]}")
    def parse(self):
        statements = []
        while self.current_token()[0] != "EOF":
            if self.current_token()[0] == "NEWLINE":
                self.eat("NEWLINE")
            else:
                statements.append(self.parse_statement())
        return Program(statements)
    def parse_statement(self):
        if self.current_token()[0] == "ID":
            next_token = self.tokens[self.pos + 1]
            # Assignment
            if next_token[0] == "ASSIGN":
                return self.parse_assignment()
            # Function call
            elif next_token[0] == "LPAREN":
                return self.parse_expression()
        raise SyntaxError("Invalid statement")
    def parse_assignment(self):
        name = self.eat("ID")[1]
        self.eat("ASSIGN")
        value = self.parse_expression()
        return Assign(Name(name), value)
    def parse_expression(self):
        node = self.parse_term()
        # Handle concatenation ( + )
        while self.current_token()[0] == "PLUS":
            self.eat("PLUS")
            right = self.parse_term()
            node = BinaryExpression(node, right)
        return node
    def parse_term(self):
        token = self.current_token()
        # String literal
        if token[0] == "STRING":
            return Literal(self.eat("STRING")[1].strip('"'))
        # Variable or function call
        elif token[0] == "ID":
            name = self.eat("ID")[1]
            # Function call
            if self.current_token()[0] == "LPAREN":
                self.eat("LPAREN")
                args = []
                if self.current_token()[0] != "RPAREN":
                    args.append(self.parse_expression())
                self.eat("RPAREN")
                return Call(name, args)
            return Name(name)
        else:
            raise SyntaxError("Invalid expression")
