from ast_nodes import *

class SinkDetector:
    def __init__(self, symbol_table):
        self.symtab = symbol_table

    def detect(self, node):
        if isinstance(node, Program):
            for stmt in node.statements:
                self.detect(stmt)

        elif isinstance(node, Call):

            # -------- XSS SINK --------
            if node.func == "print":
                for arg in node.args:
                    if isinstance(arg, Name) and self.symtab.is_tainted(arg.id):
                        print("[!] Vulnerability detected: tainted data passed to print (XSS)")

            # -------- SQL INJECTION SINK --------
            elif node.func == "execute":
                for arg in node.args:
                    if isinstance(arg, Name) and self.symtab.is_tainted(arg.id):
                        print("[!] Vulnerability detected: tainted data passed to execute (SQL Injection)")
