user = input()
query = "SELECT * FROM users WHERE name = '" + user + "'"
execute(query)
