from lexical import lexer
from parser import Parser
from symbol_table import SymbolTable
from taint_engine import TaintAnalyzer
from sink_detector import SinkDetector
from sanitization_engine import SanitizationEngine
from code_generator import CodeGenerator
with open("test.py", "r") as f:
    code = f.read()
tokens = lexer(code)
parser = Parser(tokens)
ast = parser.parse()

# Step 1: Taint analysis
symtab = SymbolTable()
taint = TaintAnalyzer(symtab)
taint.analyze(ast)

# Step 2: Sink detection
sink = SinkDetector(symtab)
sink.detect(ast)

# Step 3: Sanitization injection
sanitizer = SanitizationEngine(symtab)
sanitizer.inject(ast)

print("\nFinal Taint Status:")
for name, symbol in symtab.table.items():
    print(name, symbol.taint_state)

# sanitized code generator
generator = CodeGenerator()
secure_code = generator.generate(ast)

print("\n===== SECURE SANITIZED CODE =====")
print(secure_code)    
