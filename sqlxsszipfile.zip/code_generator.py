from ast_nodes import *

class CodeGenerator:
    def generate(self, node):

        if isinstance(node, Program):
            code = ""
            for stmt in node.statements:
                code += self.generate(stmt) + "\n"
            return code.strip()

        elif isinstance(node, Assign):
            return f"{self.generate(node.target)} = {self.generate(node.value)}"

        elif isinstance(node, Call):
            args = ", ".join(self.generate(arg) for arg in node.args)
            return f"{node.func}({args})"

        elif isinstance(node, BinaryExpression): 
            return f"{self.generate(node.left)} + {self.generate(node.right)}"

        elif isinstance(node, Name):
            return node.id

        elif isinstance(node, Literal):
            return f'"{node.value}"'

        else:
            raise Exception(f"Unsupported AST node: {type(node).__name__}")
