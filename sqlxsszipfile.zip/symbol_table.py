class Symbol:
    def __init__(self, name):
        self.name = name
        self.taint_state = "CLEAN"  
        # CLEAN | TAINTED | SANITIZED_XSS | SANITIZED_SQL

class SymbolTable:
    def __init__(self):
        self.table = {}

    def declare(self, name):
        if name not in self.table:
            self.table[name] = Symbol(name)

    def taint(self, name):
        self.table[name].taint_state = "TAINTED"

    def clean(self, name):
        self.table[name].taint_state = "CLEAN"

    def sanitize_xss(self, name):
        self.table[name].taint_state = "SANITIZED_XSS"

    def sanitize_sql(self, name):
        self.table[name].taint_state = "SANITIZED_SQL"

    def is_tainted(self, name):
        if name not in self.table:
            return False
        return self.table[name].taint_state == "TAINTED"
