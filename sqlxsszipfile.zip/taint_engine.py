from ast_nodes import *

class TaintAnalyzer:
    def __init__(self, symbol_table):
        self.symtab = symbol_table

    # 🔥 Helper: recursively check if expression is tainted
    def is_expr_tainted(self, expr):
        if isinstance(expr, Name):
            return self.symtab.is_tainted(expr.id)

        elif isinstance(expr, BinaryExpression):
            return self.is_expr_tainted(expr.left) or \
                   self.is_expr_tainted(expr.right)

        elif isinstance(expr, Call):
            # If function call argument is tainted
            for arg in expr.args:
                if isinstance(arg, Name) and self.symtab.is_tainted(arg.id):
                    return True

        return False

    def analyze(self, node):

        # Program root
        if isinstance(node, Program):
            for stmt in node.statements:
                self.analyze(stmt)

        # Assignment
        elif isinstance(node, Assign):
            var_name = node.target.id
            self.symtab.declare(var_name)

            # Case 1: x = input()
            if isinstance(node.value, Call) and node.value.func == "input":
                self.symtab.taint(var_name)

            # Case 2: x = sanitize(...)
            elif isinstance(node.value, Call) and node.value.func.startswith("sanitize"):
                self.symtab.clean(var_name)

            # Case 3: x = expression (including BinaryExpression)
            else:
                if self.is_expr_tainted(node.value):
                    self.symtab.taint(var_name)
                else:
                    self.symtab.clean(var_name)

        # Function calls (sink awareness)
        elif isinstance(node, Call):
            for arg in node.args:
                if isinstance(arg, Name) and self.symtab.is_tainted(arg.id):
                    print(f"[!] Tainted data used in call to {node.func}")
