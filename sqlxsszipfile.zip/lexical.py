# lexer/lexer.py
import re
from typing import List, Tuple
# Token specification: (TOKEN_NAME, REGEX)
token_specification = [
    ('STRING',   r'"[^"]*"'),
    ('NUMBER',   r'\d+'),
    ('ID',       r'[A-Za-z_]\w*'),
    ('ASSIGN',   r'='),
    ('PLUS',     r'\+'),
    ('LPAREN',   r'\('),
    ('RPAREN',   r'\)'),
    ('COMMA',    r','),
    ('NEWLINE',  r'\n'),
    ('SKIP',     r'[ \t]+'),
    ('MISMATCH', r'.'),
]
Token = Tuple[str, str]
def lexer(code: str) -> List[Token]:
    tokens = []
    regex_parts = []
    for name, regex in token_specification:
        regex_parts.append(f"(?P<{name}>{regex})")
    master_regex = re.compile("|".join(regex_parts))
    for match in master_regex.finditer(code):
        kind = match.lastgroup
        value = match.group()
        if kind == "SKIP":
            continue
        elif kind == "MISMATCH":
            raise RuntimeError(f"Unexpected character: {value}")
        else:
            tokens.append((kind, value))
    tokens.append(("EOF", ""))
    return tokens
    token_list = lexer(source_code)
    for token in token_list:
        print(token)
