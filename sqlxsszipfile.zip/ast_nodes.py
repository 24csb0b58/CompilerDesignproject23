# ast/ast_nodes.py

class ASTNode:
    pass

class Program(ASTNode):
    def __init__(self, statements):
        self.statements = statements

class Assign(ASTNode):
    def __init__(self, target, value):
        self.target = target
        self.value = value

class Name(ASTNode):
    def __init__(self, id):
        self.id = id

class Call(ASTNode):
    def __init__(self, func, args):
        self.func = func
        self.args=args

class Literal(ASTNode):
    def __init__(self, value):
        self.value = value

class Sanitize(ASTNode):
    def __init__(self, variable):
        self.variable = variable
class BinaryExpression:
    def __init__(self, left, right):
        self.left = left
        self.right = right
