from ast_nodes import *

class SanitizationEngine:
    def __init__(self, symbol_table):
        self.symtab = symbol_table

    def inject(self, node):
        new_statements = []

        if isinstance(node, Program):
            for stmt in node.statements:

                # -------- XSS SINK --------
                if isinstance(stmt, Call) and stmt.func == "print":
                    for arg in stmt.args:
                        if isinstance(arg, Name) and self.symtab.is_tainted(arg.id):
                            sanitize_stmt = Assign(
                                Name(arg.id),
                                Call("sanitize_xss", [Name(arg.id)])
                            )
                            new_statements.append(sanitize_stmt)
                            self.symtab.sanitize_xss(arg.id)

                # -------- SQL SINK --------
                elif isinstance(stmt, Call) and stmt.func == "execute":
                    for arg in stmt.args:
                        if isinstance(arg, Name) and self.symtab.is_tainted(arg.id):
                            sanitize_stmt = Assign(
                                Name(arg.id),
                                Call("sanitize_sql", [Name(arg.id)])
                            )
                            new_statements.append(sanitize_stmt)
                            self.symtab.sanitize_sql(arg.id)

                new_statements.append(stmt)

            node.statements = new_statements
